# Roborace Ubuntu Fix

#Install:

- Clone the original repo (https://github.com/vadbut/Roborace-Dreams)
- Copy the 'drivers' folder into 'Roborace-Dreams/src/' and choose to overwrite all conflicting files

